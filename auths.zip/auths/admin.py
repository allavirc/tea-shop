from django.contrib import admin

from auths.models import Hobbies, CustomUser

admin.site.register(Hobbies)
admin.site.register(CustomUser)
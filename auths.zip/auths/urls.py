from django.urls import path
from auths import views

urlpatterns = [
    path('hello/', views.hello),
]